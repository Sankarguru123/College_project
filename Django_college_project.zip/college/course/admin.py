from django.contrib import admin

# Register your models here.

from .models import Course,Department,Student


# admin.site.register(Course)
# admin.site.register(Department)
# admin.site.register(Student)




@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):

      models = Course

      list_display = ('name','description','status')
      list_filter = ('name',)




@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):

    models = Department

    search_fields = ('course__name',)
    list_display = ('name','description','status','get_course_name')
    list_filter = ('name',)



@admin.register(Student)

class StudentAdmin(admin.ModelAdmin):

    models = Student

    list_display = ('get_department_name','get_department_course_name','first_name','last_name','email','phone_number','address')

    search_fields = ('department__name','department__course__name')

    list_filter = ('email',)