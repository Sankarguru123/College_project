from django.db import models

# Create your models here.


## courses Models
class Course(models.Model):

    name =  models.CharField(max_length=200)
    description = models.TextField()
    status = models.BooleanField(default=True)



    def __str__(self):

        return str(self.name)



###Departments ###
class Department(models.Model):

    name = models.CharField(max_length=200)
    description = models.TextField()
    status = models.BooleanField(default=True)
    course = models.ForeignKey(Course,on_delete=models.CASCADE)


    def __str__(self):

      return (self.name)


    def get_course_name(self):

        return str(self.course.name)

    get_course_name.short_description = "Course Name"



class Student(models.Model):

     first_name = models.CharField(max_length=200)
     last_name = models.CharField(max_length=200)
     email = models.EmailField()
     address = models.TextField()
     phone_number = models.IntegerField()
     department = models.ForeignKey(Department, on_delete=models.CASCADE)


     def __str__(self):
         return self.first_name + ''+ self.last_name



     def get_department_name(self):

         return str(self.department.name)

     get_department_name.short_description = 'Department'



     def get_department_course_name(self):

         return str(self.department.course.name)


     get_department_course_name.short_description='Course'








